package com.example.smart_house_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class room_add_Class : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.room_add_activity)
        val recycler_room_add: RecyclerView = findViewById(R.id.recycler_room_add)
        recycler_room_add.layoutManager = LinearLayoutManager(this)

    }
}
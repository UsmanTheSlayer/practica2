package com.example.smart_house_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class room_add_adapter (private val room: List<String>) :
    RecyclerView.Adapter<room_add_adapter.MyViewHolder>() {

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val Image_room_add: ImageView = itemView.findViewById(R.id.image_room)
        val Text_room_add: TextView = itemView.findViewById(R.id.text_room_add)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.room_add_recycler_item, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.Text_room_add.text = room[position]
    }

    override fun getItemCount() = room.size
}



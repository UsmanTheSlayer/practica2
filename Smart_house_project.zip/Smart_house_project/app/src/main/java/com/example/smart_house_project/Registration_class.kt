package com.example.smart_house_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.GoTrue
import io.github.jan.supabase.gotrue.gotrue
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Returning
import kotlinx.coroutines.launch

class Registration_class : AppCompatActivity() {
    var mail: String? = null
    var name: String? = null
    var adress_p: String? = null
    var pass: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.registration_activity)
        val name_edit = findViewById(R.id.name_edit) as EditText
        val email_edit = findViewById(R.id.email_edit) as EditText
        val password_edit = findViewById(R.id.password_edit) as EditText
        val btnLog = findViewById(R.id.btn_log) as Button
        val btnReg = findViewById(R.id.button_registration) as Button
        val client = createSupabaseClient(
            supabaseUrl = "https://frwzdxnvfejlwekzzhat.supabase.co",
            supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZyd3pkeG52ZmVqbHdla3p6aGF0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTgzMTIzMTIsImV4cCI6MjAxMzg4ODMxMn0.Hcftjvx9ruC4rxSZhzjB79iU9sWVOfmkMhp87W4vBiA"
        ) {
            install(GoTrue)
            install(Postgrest)
        }

        email_edit.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0.isValidEmail()){
                    email_edit.error = null
                    btnReg.isEnabled = true
                }else{
                    email_edit.error = "Введите E-mail."
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                mail= email_edit.text.toString()
            }
        })
        name_edit.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){
                        name_edit.error = null
                        btnReg.isEnabled = true
                    }else{
                        name_edit.error = "Нужно ввести пароль."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                name = name_edit.text.toString()
            }
        })
        password_edit.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){

                        password_edit.error = null
                    }else{
                        password_edit.error = "Нужно ввести имя пользователя."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                pass = password_edit.text.toString()

            }
        })
        btnReg.setOnClickListener(object : View.OnClickListener{
            override fun onClick(view: View?) {
                lifecycleScope.launch {
                    val user = client.gotrue.signUpWith(Email) {
                        email = mail.toString()
                        password =  pass.toString()
                    }
                    val user_id = client.gotrue.retrieveUserForCurrentSession(updateSession = true)
                    var profile = profile(user_id.id.toString(),username=name.toString())
                    client.postgrest["profile"].insert(profile)
                }
                val intent1 = Intent(this@Registration_class, address_class::class.java)
                intent.putExtra("name", name)
                startActivity(intent1)
                val intent = Intent(applicationContext, PIN_reg_class::class.java)
                startActivity(intent)
            }
        })
        btnLog.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                val intent = Intent(applicationContext, Login_class::class.java)
                startActivity(intent)
            }
        })
    }
}